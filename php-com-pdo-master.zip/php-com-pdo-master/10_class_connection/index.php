<?php

require_once "IConn.php";
require_once "Conn.php";

$db = new Conn("localhost","test_oo","root","root");

