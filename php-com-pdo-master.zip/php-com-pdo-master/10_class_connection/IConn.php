<?php

interface IConn
{
    public function connect();
}